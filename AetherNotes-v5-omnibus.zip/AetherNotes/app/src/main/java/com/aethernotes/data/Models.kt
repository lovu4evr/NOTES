package com.aethernotes.data

data class Note(
    val id: String,
    val title: String,
    val body: String,
    val updatedAt: Long,
    val pinned: Boolean = false,
    val archived: Boolean = false,
    val tags: List<String> = emptyList(),
    val notebook: String = "Inbox",
    val linkedTodoId: String = "",
    val backlinks: List<String> = emptyList()
)

data class SubTask(val id: String, val title: String, val done: Boolean = false)

data class Todo(
    val id: String,
    val title: String,
    val done: Boolean = false,
    val dueAt: Long = 0L,
    val focusArmed: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val priority: Int = 2,
    val projectId: String = "",
    val recur: String = "", // "", daily, weekly
    val subtasks: List<SubTask> = emptyList(),
    val doneRubric: String = "",
    val estimateMin: Int = 0,
    val template: String = ""
)

data class Project(
    val id: String,
    val name: String,
    val status: String = "Todo" // Todo, Doing, Done
)

data class FocusProfile(
    val id: String,
    val name: String,
    val whitelist: List<String> = emptyList(),
    val hardMode: Boolean = false
)

data class FocusEvent(
    val ts: Long,
    val kind: String,
    val detail: String
)

data class Evidence(
    val todoId: String,
    val uri: String,
    val ts: Long
)

object Templates {
    val ALL = listOf(
        "Study chapter" to "Read + notes + 5 practice Qs",
        "Gym session" to "Warmup + main lifts + stretch",
        "Ship build" to "Build green + commit + note changelog",
        "Deep work" to "45 min uninterrupted on one outcome"
    )
}
