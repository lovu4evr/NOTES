package com.aethernotes.focus

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import com.aethernotes.MainActivity
import com.aethernotes.data.Repo

class FocusLockService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        val armed = Repo.armedFocusTodo(this) ?: return
        if (armed.done || !armed.focusArmed) return
        if (pkg in Repo.whitelist(this)) return
        Repo.logFocus(this, "block", pkg)
        val i = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            .putExtra("focus_block", true)
            .putExtra("todo_id", armed.id)
        startActivity(i)
    }

    override fun onInterrupt() {}
}
