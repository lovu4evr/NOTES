package com.aethernotes.security

import android.content.Context
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.aethernotes.data.Repo

object AppLock {
    fun needsLock(c: Context): Boolean =
        Repo.pinHash(c).isNotBlank() || Repo.biometricOn(c)

    fun canBiometric(c: Context): Boolean {
        val bm = BiometricManager.from(c)
        return bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS
    }

    fun checkPin(c: Context, pin: String): Boolean =
        Repo.pinHash(c).isNotBlank() && Repo.pinHash(c) == pin.hashCode().toString()

    fun checkSecondPin(c: Context, pin: String): Boolean {
        val h = Repo.secondPin(c)
        return h.isNotBlank() && h == pin.hashCode().toString()
    }

    fun promptBiometric(act: FragmentActivity, onOk: () -> Unit, onFail: (String) -> Unit) {
        val prompt = BiometricPrompt(act, ContextCompat.getMainExecutor(act),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) = onOk()
                override fun onAuthenticationError(code: Int, err: CharSequence) = onFail(err.toString())
                override fun onAuthenticationFailed() = onFail("Failed")
            })
        prompt.authenticate(
            BiometricPrompt.PromptInfo.Builder()
                .setTitle("Unlock Aether")
                .setNegativeButtonText("Cancel")
                .build()
        )
    }
}
