package com.aethernotes.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/**
 * Local-first store for v2–v5 entities (JSON files under filesDir/aether).
 * Room can replace this later without changing UI contracts much.
 */
object Repo {
    private fun dir(c: Context) = File(c.filesDir, "aether").also { if (!it.exists()) it.mkdirs() }
    private fun file(c: Context, name: String) = File(dir(c), name)
    private fun prefs(c: Context) = c.getSharedPreferences("aether_meta", Context.MODE_PRIVATE)

    fun newId() = UUID.randomUUID().toString().take(10)

    // ── Notes ──
    fun notes(c: Context, includeArchived: Boolean = false): List<Note> {
        val arr = readArr(c, "notes.json")
        val out = ArrayList<Note>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val n = Note(
                id = o.getString("id"),
                title = o.optString("title"),
                body = o.optString("body"),
                updatedAt = o.optLong("updatedAt"),
                pinned = o.optBoolean("pinned"),
                archived = o.optBoolean("archived"),
                tags = o.optJSONArray("tags")?.toStrList() ?: emptyList(),
                notebook = o.optString("notebook", "Inbox"),
                linkedTodoId = o.optString("linkedTodoId"),
                backlinks = o.optJSONArray("backlinks")?.toStrList() ?: emptyList()
            )
            if (includeArchived || !n.archived) out.add(n)
        }
        return out.sortedWith(compareByDescending<Note> { it.pinned }.thenByDescending { it.updatedAt })
    }

    fun saveNote(c: Context, note: Note) {
        val list = notes(c, true).toMutableList()
        val i = list.indexOfFirst { it.id == note.id }
        if (i >= 0) list[i] = note else list.add(0, note)
        // simple backlink: [[NoteTitle]] in body
        writeNotes(c, list)
    }

    fun deleteNote(c: Context, id: String) = writeNotes(c, notes(c, true).filter { it.id != id })

    private fun writeNotes(c: Context, list: List<Note>) {
        val arr = JSONArray()
        list.forEach { n ->
            arr.put(
                JSONObject()
                    .put("id", n.id).put("title", n.title).put("body", n.body)
                    .put("updatedAt", n.updatedAt).put("pinned", n.pinned).put("archived", n.archived)
                    .put("tags", JSONArray(n.tags)).put("notebook", n.notebook)
                    .put("linkedTodoId", n.linkedTodoId).put("backlinks", JSONArray(n.backlinks))
            )
        }
        writeArr(c, "notes.json", arr)
    }

    // ── Todos ──
    fun todos(c: Context): List<Todo> {
        val arr = readArr(c, "todos.json")
        val out = ArrayList<Todo>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val subs = ArrayList<SubTask>()
            o.optJSONArray("subtasks")?.let { sa ->
                for (j in 0 until sa.length()) {
                    val s = sa.getJSONObject(j)
                    subs.add(SubTask(s.getString("id"), s.optString("title"), s.optBoolean("done")))
                }
            }
            out.add(
                Todo(
                    id = o.getString("id"),
                    title = o.optString("title"),
                    done = o.optBoolean("done"),
                    dueAt = o.optLong("dueAt"),
                    focusArmed = o.optBoolean("focusArmed"),
                    createdAt = o.optLong("createdAt", System.currentTimeMillis()),
                    priority = o.optInt("priority", 2),
                    projectId = o.optString("projectId"),
                    recur = o.optString("recur"),
                    subtasks = subs,
                    doneRubric = o.optString("doneRubric"),
                    estimateMin = o.optInt("estimateMin"),
                    template = o.optString("template")
                )
            )
        }
        return out.sortedWith(
            compareBy<Todo> { it.done }
                .thenBy { it.priority }
                .thenBy { if (it.dueAt == 0L) Long.MAX_VALUE else it.dueAt }
        )
    }

    fun saveTodo(c: Context, todo: Todo) {
        val list = todos(c).toMutableList()
        val i = list.indexOfFirst { it.id == todo.id }
        if (i >= 0) list[i] = todo else list.add(0, todo)
        writeTodos(c, list)
    }

    fun deleteTodo(c: Context, id: String) = writeTodos(c, todos(c).filter { it.id != id })

    fun armedFocusTodo(c: Context) = todos(c).firstOrNull { it.focusArmed && !it.done }

    fun completeTodo(c: Context, id: String) {
        val t = todos(c).firstOrNull { it.id == id } ?: return
        saveTodo(c, t.copy(done = true, focusArmed = false))
        if (t.recur == "daily" || t.recur == "weekly") {
            val next = t.dueAt.let { d ->
                val base = if (d > 0) d else System.currentTimeMillis()
                base + if (t.recur == "daily") 86_400_000L else 604_800_000L
            }
            saveTodo(
                c,
                t.copy(
                    id = newId(),
                    done = false,
                    focusArmed = false,
                    dueAt = next,
                    createdAt = System.currentTimeMillis(),
                    subtasks = t.subtasks.map { it.copy(id = newId(), done = false) }
                )
            )
        }
        prefs(c).edit().putInt("stat_done", prefs(c).getInt("stat_done", 0) + 1).apply()
        val day = java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US).format(java.util.Date())
        val last = prefs(c).getString("streak_day", "")
        val streak = prefs(c).getInt("streak", 0)
        if (last == day) { /* same day */ }
        else {
            val y = java.util.Calendar.getInstance().apply { add(java.util.Calendar.DAY_OF_YEAR, -1) }
            val yS = java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US).format(y.time)
            prefs(c).edit().putString("streak_day", day).putInt("streak", if (last == yS) streak + 1 else 1).apply()
        }
    }

    private fun writeTodos(c: Context, list: List<Todo>) {
        val arr = JSONArray()
        list.forEach { t ->
            val subs = JSONArray()
            t.subtasks.forEach { s ->
                subs.put(JSONObject().put("id", s.id).put("title", s.title).put("done", s.done))
            }
            arr.put(
                JSONObject()
                    .put("id", t.id).put("title", t.title).put("done", t.done).put("dueAt", t.dueAt)
                    .put("focusArmed", t.focusArmed).put("createdAt", t.createdAt)
                    .put("priority", t.priority).put("projectId", t.projectId).put("recur", t.recur)
                    .put("subtasks", subs).put("doneRubric", t.doneRubric)
                    .put("estimateMin", t.estimateMin).put("template", t.template)
            )
        }
        writeArr(c, "todos.json", arr)
    }

    // ── Projects ──
    fun projects(c: Context): List<Project> {
        val arr = readArr(c, "projects.json")
        val out = ArrayList<Project>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(Project(o.getString("id"), o.optString("name"), o.optString("status", "Todo")))
        }
        return out
    }

    fun saveProject(c: Context, p: Project) {
        val list = projects(c).toMutableList()
        val i = list.indexOfFirst { it.id == p.id }
        if (i >= 0) list[i] = p else list.add(p)
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("id", it.id).put("name", it.name).put("status", it.status)) }
        writeArr(c, "projects.json", arr)
    }

    // ── Focus profiles & events ──
    fun profiles(c: Context): List<FocusProfile> {
        val arr = readArr(c, "profiles.json")
        if (arr.length() == 0) {
            val defaults = listOf(
                FocusProfile("study", "Study", listOf("com.android.chrome"), false),
                FocusProfile("work", "Work", emptyList(), true)
            )
            saveProfiles(c, defaults)
            return defaults
        }
        val out = ArrayList<FocusProfile>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(
                FocusProfile(
                    o.getString("id"),
                    o.optString("name"),
                    o.optJSONArray("whitelist")?.toStrList() ?: emptyList(),
                    o.optBoolean("hardMode")
                )
            )
        }
        return out
    }

    fun saveProfiles(c: Context, list: List<FocusProfile>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("name", it.name)
                    .put("whitelist", JSONArray(it.whitelist)).put("hardMode", it.hardMode)
            )
        }
        writeArr(c, "profiles.json", arr)
    }

    fun activeProfileId(c: Context) = prefs(c).getString("active_profile", "study") ?: "study"
    fun setActiveProfile(c: Context, id: String) = prefs(c).edit().putString("active_profile", id).apply()
    fun activeProfile(c: Context) = profiles(c).firstOrNull { it.id == activeProfileId(c) } ?: profiles(c).first()

    fun whitelist(c: Context): Set<String> {
        val custom = prefs(c).getStringSet("whitelist", emptySet()) ?: emptySet()
        return custom + activeProfile(c).whitelist.toSet() + SYSTEM_SAFE
    }

    fun setWhitelist(c: Context, packages: Set<String>) =
        prefs(c).edit().putStringSet("whitelist", packages).apply()

    fun logFocus(c: Context, kind: String, detail: String) {
        val arr = readArr(c, "focus_log.json")
        arr.put(JSONObject().put("ts", System.currentTimeMillis()).put("kind", kind).put("detail", detail))
        while (arr.length() > 300) arr.remove(0)
        writeArr(c, "focus_log.json", arr)
    }

    fun focusLog(c: Context): List<FocusEvent> {
        val arr = readArr(c, "focus_log.json")
        val out = ArrayList<FocusEvent>()
        for (i in arr.length() - 1 downTo 0) {
            val o = arr.getJSONObject(i)
            out.add(FocusEvent(o.optLong("ts"), o.optString("kind"), o.optString("detail")))
        }
        return out
    }

    // ── Evidence ──
    fun addEvidence(c: Context, todoId: String, uri: String) {
        val arr = readArr(c, "evidence.json")
        arr.put(JSONObject().put("todoId", todoId).put("uri", uri).put("ts", System.currentTimeMillis()))
        writeArr(c, "evidence.json", arr)
    }

    fun evidenceFor(c: Context, todoId: String): List<Evidence> {
        val arr = readArr(c, "evidence.json")
        val out = ArrayList<Evidence>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.optString("todoId") == todoId)
                out.add(Evidence(todoId, o.optString("uri"), o.optLong("ts")))
        }
        return out
    }

    // ── Settings / stats ──
    fun apiUrl(c: Context) = prefs(c).getString("api_url", "") ?: ""
    fun apiKey(c: Context) = prefs(c).getString("api_key", "") ?: ""
    fun model(c: Context) = prefs(c).getString("model", "gpt-4o-mini") ?: "gpt-4o-mini"
    fun setApi(c: Context, url: String, key: String, model: String) {
        prefs(c).edit().putString("api_url", url.trim()).putString("api_key", key.trim())
            .putString("model", model.trim().ifBlank { "gpt-4o-mini" }).apply()
    }

    fun onboardingDone(c: Context) = prefs(c).getBoolean("onboarded", false)
    fun setOnboarded(c: Context) = prefs(c).edit().putBoolean("onboarded", true).apply()

    fun pinHash(c: Context) = prefs(c).getString("pin_hash", "") ?: ""
    fun setPin(c: Context, pin: String) = prefs(c).edit().putString("pin_hash", pin.hashCode().toString()).apply()
    fun clearPin(c: Context) = prefs(c).edit().remove("pin_hash").apply()
    fun biometricOn(c: Context) = prefs(c).getBoolean("bio", false)
    fun setBiometric(c: Context, on: Boolean) = prefs(c).edit().putBoolean("bio", on).apply()

    fun accent(c: Context) = prefs(c).getString("accent", "purple") ?: "purple"
    fun setAccent(c: Context, a: String) = prefs(c).edit().putString("accent", a).apply()

    fun hardMode(c: Context) = activeProfile(c).hardMode || prefs(c).getBoolean("hard_mode", false)
    fun secondPin(c: Context) = prefs(c).getString("second_pin", "") ?: ""
    fun setSecondPin(c: Context, pin: String) = prefs(c).edit().putString("second_pin", pin.hashCode().toString()).apply()

    fun focusedMinutes(c: Context) = prefs(c).getInt("focus_min", 0)
    fun addFocusedMinutes(c: Context, m: Int) =
        prefs(c).edit().putInt("focus_min", focusedMinutes(c) + m).apply()

    fun statDone(c: Context) = prefs(c).getInt("stat_done", 0)
    fun streak(c: Context) = prefs(c).getInt("streak", 0)

    fun sessionUntil(c: Context) = prefs(c).getLong("session_until", 0L)
    fun startSession(c: Context, minutes: Int) {
        prefs(c).edit().putLong("session_until", System.currentTimeMillis() + minutes * 60_000L).apply()
        addFocusedMinutes(c, 0)
    }

    // ── Backup ──
    fun exportAll(c: Context): String {
        val root = JSONObject()
        root.put("format", 5)
        root.put("notes", readArr(c, "notes.json"))
        root.put("todos", readArr(c, "todos.json"))
        root.put("projects", readArr(c, "projects.json"))
        root.put("profiles", readArr(c, "profiles.json"))
        root.put("ts", System.currentTimeMillis())
        return root.toString(2)
    }

    fun importAll(c: Context, json: String): String {
        val root = JSONObject(json)
        if (root.has("notes")) writeArr(c, "notes.json", root.getJSONArray("notes"))
        if (root.has("todos")) writeArr(c, "todos.json", root.getJSONArray("todos"))
        if (root.has("projects")) writeArr(c, "projects.json", root.getJSONArray("projects"))
        if (root.has("profiles")) writeArr(c, "profiles.json", root.getJSONArray("profiles"))
        return "Imported format ${root.optInt("format")}"
    }

    fun exportFile(c: Context): File {
        val f = File(c.getExternalFilesDir(null) ?: c.filesDir, "aether-backup.json")
        f.writeText(exportAll(c))
        return f
    }

    // ── IO helpers ──
    private fun readArr(c: Context, name: String): JSONArray {
        val f = file(c, name)
        if (!f.exists()) return JSONArray()
        return try { JSONArray(f.readText()) } catch (_: Exception) { JSONArray() }
    }

    private fun writeArr(c: Context, name: String, arr: JSONArray) {
        file(c, name).writeText(arr.toString())
    }

    private fun JSONArray.toStrList(): List<String> {
        val out = ArrayList<String>()
        for (i in 0 until length()) out.add(optString(i))
        return out
    }

    val SYSTEM_SAFE = setOf(
        "com.android.systemui", "com.android.settings", "com.google.android.permissioncontroller",
        "com.android.permissioncontroller", "com.android.phone", "com.android.incallui",
        "com.google.android.gms", "com.android.intentresolver", "com.google.android.packageinstaller",
        "com.android.packageinstaller", "com.aethernotes"
    )
}
