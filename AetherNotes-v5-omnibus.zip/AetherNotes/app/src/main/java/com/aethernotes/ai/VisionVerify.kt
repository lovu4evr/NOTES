package com.aethernotes.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import com.aethernotes.data.Repo
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

object VisionVerify {
    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .build()

    data class Result(val done: Boolean, val confidence: Double, val reason: String)

    fun analyze(c: Context, uris: List<Uri>, taskTitle: String, rubric: String): Result {
        val url = Repo.apiUrl(c).trim().trimEnd('/')
        val key = Repo.apiKey(c)
        if (url.isBlank() || key.isBlank()) {
            return offlineFallback(taskTitle, uris.isNotEmpty())
        }
        val content = JSONArray()
        content.put(
            JSONObject().put("type", "text").put(
                "text",
                """
                Verify if this task is DONE from screenshot(s).
                Task: "$taskTitle"
                Rubric: "${rubric.ifBlank { "clear evidence of completed work product" }}"
                Reply ONLY JSON: {"done":true|false,"confidence":0.0-1.0,"reason":"short"}
                If unrelated/spam/unclear → done=false.
                """.trimIndent()
            )
        )
        uris.take(3).forEach { uri ->
            val b64 = encode(c, uri) ?: return@forEach
            content.put(
                JSONObject().put("type", "image_url")
                    .put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$b64"))
            )
        }
        if (content.length() < 2) return Result(false, 0.0, "No readable images")

        val body = JSONObject()
            .put("model", Repo.model(c))
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
            .put("max_tokens", 250)

        val req = Request.Builder()
            .url("$url/chat/completions")
            .header("Authorization", "Bearer $key")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        http.newCall(req).execute().use { res ->
            val t = res.body?.string().orEmpty()
            if (!res.isSuccessful) return Result(false, 0.0, "API ${res.code}: ${t.take(100)}")
            val contentStr = JSONObject(t).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").optString("content")
            return parse(contentStr)
        }
    }

    fun offlineFallback(taskTitle: String, hasImage: Boolean): Result {
        if (!hasImage) return Result(false, 0.0, "Add API in Settings or attach a screenshot for self-attest.")
        return Result(false, 0.2, "Offline mode: use self-attest after reviewing “$taskTitle” (API not configured).")
    }

    fun selfAttest(c: Context, todoId: String): Result {
        Repo.logFocus(c, "self_attest", todoId)
        return Result(true, 0.5, "Self-attested completion (offline).")
    }

    private fun parse(content: String): Result {
        val s = content.indexOf('{'); val e = content.lastIndexOf('}')
        if (s < 0 || e <= s) return Result(false, 0.0, content.take(120))
        return try {
            val o = JSONObject(content.substring(s, e + 1))
            Result(o.optBoolean("done"), o.optDouble("confidence", 0.5), o.optString("reason"))
        } catch (ex: Exception) {
            Result(false, 0.0, ex.message ?: "parse")
        }
    }

    private fun encode(c: Context, uri: Uri): String? = try {
        c.contentResolver.openInputStream(uri)?.use { input ->
            val bmp = BitmapFactory.decodeStream(input) ?: return null
            val scaled = scale(bmp, 1280)
            val baos = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, 80, baos)
            Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
        }
    } catch (_: Exception) { null }

    private fun scale(src: Bitmap, max: Int): Bitmap {
        val m = maxOf(src.width, src.height)
        if (m <= max) return src
        val s = max.toFloat() / m
        return Bitmap.createScaledBitmap(src, (src.width * s).toInt(), (src.height * s).toInt(), true)
    }
}
