package com.aethernotes

import android.Manifest
import android.app.AlarmManager
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import com.aethernotes.ai.VisionVerify
import com.aethernotes.data.*
import com.aethernotes.focus.TodoAlarmReceiver
import com.aethernotes.security.AppLock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val BG = Color(0xFF07040F)
private val CARD = Color(0xFF140A22)
private val PURPLE = Color(0xFFA855F7)
private val PINK = Color(0xFFE879F9)
private val CYAN = Color(0xFF22D3EE)
private val TEXT = Color(0xFFF5F3FF)
private val MUTED = Color(0xFFA78BBA)

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
                .launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        val shareText = intent?.takeIf { it.action == Intent.ACTION_SEND }?.getStringExtra(Intent.EXTRA_TEXT)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = PURPLE, background = BG, surface = CARD)) {
                var unlocked by remember {
                    mutableStateOf(!AppLock.needsLock(this@MainActivity))
                }
                when {
                    !unlocked -> LockGate(this) { unlocked = true }
                    !Repo.onboardingDone(this) -> Onboarding { Repo.setOnboarded(this); }
                    else -> AetherRoot(
                        focusBlock = intent?.getBooleanExtra("focus_block", false) == true,
                        shareText = shareText
                    )
                }
            }
        }
    }
}

@Composable
private fun LockGate(act: FragmentActivity, onOk: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().background(BG).padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("AETHER", color = TEXT, fontSize = 28.sp, fontWeight = FontWeight.Black)
        Text("Unlock", color = MUTED)
        Spacer(Modifier.height(16.dp))
        if (Repo.pinHash(ctx).isNotBlank()) {
            OutlinedTextField(pin, { pin = it }, label = { Text("PIN") }, singleLine = true)
            Button({
                if (AppLock.checkPin(ctx, pin)) onOk()
                else Toast.makeText(ctx, "Wrong PIN", Toast.LENGTH_SHORT).show()
            }, Modifier.padding(top = 8.dp)) { Text("Unlock") }
        }
        if (Repo.biometricOn(ctx) && AppLock.canBiometric(ctx)) {
            TextButton({ AppLock.promptBiometric(act, onOk) { Toast.makeText(ctx, it, Toast.LENGTH_SHORT).show() } }) {
                Text("Biometric", color = PINK)
            }
        }
    }
}

@Composable
private fun Onboarding(onDone: () -> Unit) {
    var step by remember { mutableStateOf(0) }
    val titles = listOf(
        "Notes that feel alive" to "Depth cards, tags, notebooks, search.",
        "Tasks with real time" to "Due alarms, snooze, recurring, priorities.",
        "Focus Lock + AI unlock" to "Arm a task, stay locked, prove done with screenshots."
    )
    Column(Modifier.fillMaxSize().background(BG).padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("Welcome to Aether 5", color = TEXT, fontSize = 24.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(12.dp))
        Text(titles[step].first, color = PINK, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text(titles[step].second, color = MUTED)
        Spacer(Modifier.height(24.dp))
        Button(
            onClick = { if (step < 2) step++ else onDone() },
            colors = ButtonDefaults.buttonColors(containerColor = PURPLE),
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (step < 2) "Next" else "Start") }
    }
}

@Composable
fun AetherRoot(focusBlock: Boolean, shareText: String?) {
    val ctx = LocalContext.current
    var tab by remember { mutableStateOf(0) }
    var notes by remember { mutableStateOf(Repo.notes(ctx)) }
    var todos by remember { mutableStateOf(Repo.todos(ctx)) }
    var projects by remember { mutableStateOf(Repo.projects(ctx)) }
    val armed = todos.firstOrNull { it.focusArmed && !it.done }
    val a11yOn = isAccessibilityEnabled(ctx)
    val scope = rememberCoroutineScope()

    LaunchedEffect(shareText) {
        if (!shareText.isNullOrBlank()) {
            Repo.saveNote(ctx, Note(Repo.newId(), "Quick capture", shareText, System.currentTimeMillis()))
            notes = Repo.notes(ctx)
            Toast.makeText(ctx, "Saved shared text", Toast.LENGTH_SHORT).show()
        }
    }

    fun refresh() {
        notes = Repo.notes(ctx)
        todos = Repo.todos(ctx)
        projects = Repo.projects(ctx)
    }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0B0618), BG)))) {
        val inf = rememberInfiniteTransition(label = "o")
        val d by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(8000, easing = FastOutSlowInEasing), RepeatMode.Reverse), "d")
        Box(Modifier.offset((30 + d * 40).dp, (60).dp).size(160.dp).graphicsLayer { alpha = 0.3f }
            .background(Brush.radialGradient(listOf(Color(0x66A855F7), Color.Transparent)), CircleShape))

        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("AETHER 5", color = TEXT, fontSize = 24.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                    Text(
                        when {
                            armed != null && !a11yOn -> "Focus armed · enable Accessibility!"
                            armed != null -> "Focus · ${armed.title}"
                            else -> "Streak ${Repo.streak(ctx)} · ${Repo.statDone(ctx)} done"
                        },
                        color = if (armed != null && !a11yOn) Color(0xFFFCA5A5) else MUTED,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Text("${Repo.focusedMinutes(ctx)}m", color = CYAN, fontSize = 12.sp)
            }
            if (focusBlock && armed != null) {
                Text(
                    "Focus Lock: stay on “${armed.title}”",
                    color = TEXT,
                    modifier = Modifier
                        .padding(horizontal = 16.dp)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0x44EF4444))
                        .padding(10.dp),
                    fontSize = 13.sp
                )
            }
            Box(Modifier.weight(1f)) {
                when (tab) {
                    0 -> NotesScreen(notes) { refresh() }
                    1 -> TodosScreen(todos, projects) { refresh() }
                    2 -> FocusScreen(armed, a11yOn) { refresh() }
                    3 -> ProjectsScreen(projects, todos) { refresh() }
                    4 -> StatsScreen()
                    else -> SettingsScreen()
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(8.dp).clip(RoundedCornerShape(20.dp)).background(CARD)
                    .border(1.dp, Color(0x44A855F7), RoundedCornerShape(20.dp)).padding(6.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                listOf(
                    0 to Icons.Default.Notes, 1 to Icons.Default.Checklist, 2 to Icons.Default.Lock,
                    3 to Icons.Default.ViewKanban, 4 to Icons.Default.Insights, 5 to Icons.Default.Settings
                ).forEach { (i, ic) ->
                    IconButton({ tab = i }) {
                        Icon(ic, null, tint = if (tab == i) PINK else MUTED)
                    }
                }
            }
        }
    }
}

@Composable
private fun Depth(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.graphicsLayer { rotationX = 2f; cameraDistance = 16f * density; shadowElevation = 10f }
            .clip(RoundedCornerShape(18.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFF1C1030), Color(0xFF100818))))
            .border(1.dp, Color(0x55A855F7), RoundedCornerShape(18.dp))
            .padding(12.dp),
        content = content
    )
}

@Composable
private fun NotesScreen(notes: List<Note>, onChange: () -> Unit) {
    val ctx = LocalContext.current
    var q by remember { mutableStateOf("") }
    var notebook by remember { mutableStateOf("All") }
    var edit by remember { mutableStateOf<Note?>(null) }
    val books = listOf("All") + notes.map { it.notebook }.distinct()
    val filtered = notes.filter {
        (notebook == "All" || it.notebook == notebook) &&
            (q.isBlank() || it.title.contains(q, true) || it.body.contains(q, true) || it.tags.any { t -> t.contains(q, true) })
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        OutlinedTextField(q, { q = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Search notes, tags…") }, singleLine = true)
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            books.forEach { b ->
                FilterChip(notebook == b, { notebook = b }, label = { Text(b) })
            }
        }
        Button({
            edit = Note(Repo.newId(), "", "", System.currentTimeMillis())
        }, colors = ButtonDefaults.buttonColors(containerColor = PURPLE)) { Text("+ Note") }
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filtered, key = { it.id }) { n ->
                Depth(Modifier.fillMaxWidth().clickable { edit = n }) {
                    Row {
                        if (n.pinned) Icon(Icons.Default.PushPin, null, tint = CYAN, modifier = Modifier.size(14.dp))
                        Text(n.title.ifBlank { "Untitled" }, color = TEXT, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text(n.notebook, color = MUTED, fontSize = 11.sp)
                    }
                    Text(n.body, color = MUTED, maxLines = 3, overflow = TextOverflow.Ellipsis, fontSize = 13.sp)
                    if (n.tags.isNotEmpty()) Text(n.tags.joinToString(" · ") { "#$it" }, color = PINK, fontSize = 11.sp)
                }
            }
        }
    }
    edit?.let { n ->
        var title by remember(n.id) { mutableStateOf(n.title) }
        var body by remember(n.id) { mutableStateOf(n.body) }
        var tags by remember(n.id) { mutableStateOf(n.tags.joinToString(", ")) }
        var nb by remember(n.id) { mutableStateOf(n.notebook) }
        var pin by remember(n.id) { mutableStateOf(n.pinned) }
        AlertDialog(
            onDismissRequest = { edit = null },
            containerColor = CARD,
            title = { Text("Note", color = TEXT) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(title, { title = it }, label = { Text("Title") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(body, { body = it }, label = { Text("Body (markdown ok)") }, modifier = Modifier.fillMaxWidth().height(140.dp))
                    OutlinedTextField(nb, { nb = it }, label = { Text("Notebook") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(tags, { tags = it }, label = { Text("Tags comma-separated") }, modifier = Modifier.fillMaxWidth())
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Pinned", color = MUTED, modifier = Modifier.weight(1f)); Switch(pin, { pin = it })
                    }
                    TextButton({
                        // AI extract todos optional - create todos from lines starting with - [ ]
                        body.lines().filter { it.trim().startsWith("- [ ]") || it.trim().startsWith("- ") }.forEach { line ->
                            val t = line.removePrefix("- [ ]").removePrefix("- ").trim()
                            if (t.isNotBlank()) {
                                val todo = Todo(Repo.newId(), t)
                                Repo.saveTodo(ctx, todo)
                            }
                        }
                        Toast.makeText(ctx, "Extracted checklist lines to tasks", Toast.LENGTH_SHORT).show()
                        onChange()
                    }) { Text("Extract tasks from body", color = CYAN) }
                }
            },
            confirmButton = {
                TextButton({
                    Repo.saveNote(
                        ctx,
                        n.copy(
                            title = title, body = body, pinned = pin, notebook = nb.ifBlank { "Inbox" },
                            tags = tags.split(",").map { it.trim() }.filter { it.isNotEmpty() },
                            updatedAt = System.currentTimeMillis()
                        )
                    )
                    edit = null; onChange()
                }) { Text("Save", color = PINK) }
            },
            dismissButton = {
                Row {
                    TextButton({
                        Repo.saveNote(ctx, n.copy(archived = true, updatedAt = System.currentTimeMillis()))
                        edit = null; onChange()
                    }) { Text("Archive", color = MUTED) }
                    TextButton({
                        Repo.deleteNote(ctx, n.id); edit = null; onChange()
                    }) { Text("Delete", color = Color(0xFFFCA5A5) ) }
                    TextButton({ edit = null }) { Text("Close", color = MUTED) }
                }
            }
        )
    }
}

@Composable
private fun TodosScreen(todos: List<Todo>, projects: List<Project>, onChange: () -> Unit) {
    val ctx = LocalContext.current
    var title by remember { mutableStateOf("") }
    var due by remember { mutableStateOf(0L) }
    var priority by remember { mutableStateOf(2) }
    var recur by remember { mutableStateOf("") }
    var projectId by remember { mutableStateOf("") }
    var rubric by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        Depth(Modifier.fillMaxWidth()) {
            OutlinedTextField(title, { title = it }, placeholder = { Text("Task") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton({ pickDateTime(ctx) { due = it } }) { Text(if (due == 0L) "Time" else fmt(due)) }
                listOf(1 to "P1", 2 to "P2", 3 to "P3").forEach { (p, l) ->
                    FilterChip(priority == p, { priority = p }, label = { Text(l) })
                }
                FilterChip(recur == "daily", { recur = if (recur == "daily") "" else "daily" }, label = { Text("Daily") })
                FilterChip(recur == "weekly", { recur = if (recur == "weekly") "" else "weekly" }, label = { Text("Weekly") })
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Templates.ALL.forEach { (name, rub) ->
                    AssistChip({ title = name; rubric = rub }, label = { Text(name) })
                }
            }
            if (projects.isNotEmpty()) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(projectId.isEmpty(), { projectId = "" }, label = { Text("No project") })
                    projects.forEach { p ->
                        FilterChip(projectId == p.id, { projectId = p.id }, label = { Text(p.name) })
                    }
                }
            }
            Button({
                if (title.isBlank()) return@Button
                val t = Todo(
                    Repo.newId(), title.trim(), dueAt = due, priority = priority,
                    recur = recur, projectId = projectId, doneRubric = rubric, template = title
                )
                Repo.saveTodo(ctx, t)
                TodoAlarmReceiver.schedule(ctx, t)
                title = ""; due = 0L; rubric = ""; onChange()
                ensureExactAlarm(ctx)
            }, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = PURPLE)) { Text("Add task") }
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(todos, key = { it.id }) { t ->
                Depth(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(t.done, {
                            if (it) {
                                Repo.completeTodo(ctx, t.id)
                                TodoAlarmReceiver.cancel(ctx, t.id)
                            } else {
                                Repo.saveTodo(ctx, t.copy(done = false))
                            }
                            onChange()
                        })
                        Column(Modifier.weight(1f)) {
                            Text(t.title, color = if (t.done) MUTED else TEXT, fontWeight = FontWeight.SemiBold)
                            val bits = buildList {
                                if (t.dueAt > 0) add(fmt(t.dueAt))
                                add("P${t.priority}")
                                if (t.recur.isNotBlank()) add(t.recur)
                                if (t.focusArmed) add("FOCUS")
                            }
                            Text(bits.joinToString(" · "), color = CYAN, fontSize = 11.sp)
                        }
                        IconButton({
                            if (!t.done) {
                                if (!t.focusArmed) {
                                    Repo.todos(ctx).filter { it.focusArmed }.forEach { Repo.saveTodo(ctx, it.copy(focusArmed = false)) }
                                    Repo.saveTodo(ctx, t.copy(focusArmed = true))
                                    Repo.logFocus(ctx, "arm", t.title)
                                    Toast.makeText(ctx, "Armed. Enable Accessibility if needed.", Toast.LENGTH_LONG).show()
                                } else {
                                    Repo.saveTodo(ctx, t.copy(focusArmed = false))
                                    Repo.logFocus(ctx, "disarm", t.title)
                                }
                                onChange()
                            }
                        }) { Icon(if (t.focusArmed) Icons.Default.Lock else Icons.Default.LockOpen, null, tint = if (t.focusArmed) PINK else MUTED) }
                        IconButton({
                            Repo.deleteTodo(ctx, t.id); TodoAlarmReceiver.cancel(ctx, t.id); onChange()
                        }) { Icon(Icons.Default.Delete, null, tint = MUTED) }
                    }
                }
            }
        }
    }
}

@Composable
private fun FocusScreen(armed: Todo?, a11yOn: Boolean, onChange: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    val evidenceUris = remember { mutableStateListOf<Uri>() }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null && evidenceUris.size < 3) evidenceUris.add(uri)
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Depth(Modifier.fillMaxWidth()) {
            Text("Focus Lock status", color = TEXT, fontWeight = FontWeight.Bold)
            Text(
                if (a11yOn) "Accessibility service: ON" else "Accessibility service: OFF — open settings",
                color = if (a11yOn) CYAN else Color(0xFFFCA5A5)
            )
            Button({ ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }, Modifier.fillMaxWidth()) {
                Text("Accessibility settings")
            }
            if (Build.VERSION.SDK_INT >= 31) {
                Button({
                    ctx.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM))
                }, Modifier.fillMaxWidth()) { Text("Exact alarm permission") }
            }
        }
        Depth(Modifier.fillMaxWidth()) {
            Text("Profiles", color = TEXT, fontWeight = FontWeight.Bold)
            Repo.profiles(ctx).forEach { p ->
                Row(Modifier.fillMaxWidth().clickable {
                    Repo.setActiveProfile(ctx, p.id)
                    Toast.makeText(ctx, "Profile ${p.name}", Toast.LENGTH_SHORT).show()
                }, verticalAlignment = Alignment.CenterVertically) {
                    Text(p.name, color = if (Repo.activeProfileId(ctx) == p.id) PINK else TEXT, modifier = Modifier.weight(1f))
                    Text(if (p.hardMode) "Hard" else "Soft", color = MUTED, fontSize = 12.sp)
                }
            }
            Text("Whitelist packages (comma): com.android.chrome,…", color = MUTED, fontSize = 11.sp)
            var wl by remember { mutableStateOf(Repo.whitelist(ctx).filter { it !in Repo.SYSTEM_SAFE }.joinToString(",")) }
            OutlinedTextField(wl, { wl = it }, modifier = Modifier.fillMaxWidth())
            TextButton({
                Repo.setWhitelist(ctx, wl.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet())
                Toast.makeText(ctx, "Whitelist saved", Toast.LENGTH_SHORT).show()
            }) { Text("Save whitelist", color = CYAN) }
        }
        Depth(Modifier.fillMaxWidth()) {
            Text("Pomodoro session", color = TEXT, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(25, 45, 60).forEach { m ->
                    OutlinedButton({
                        Repo.startSession(ctx, m)
                        Repo.addFocusedMinutes(ctx, m)
                        Toast.makeText(ctx, "Session ${m}m logged", Toast.LENGTH_SHORT).show()
                    }) { Text("${m}m") }
                }
            }
        }
        if (armed != null) {
            Depth(Modifier.fillMaxWidth()) {
                Text("Armed: ${armed.title}", color = PINK, fontWeight = FontWeight.Bold)
                if (armed.doneRubric.isNotBlank()) Text("Rubric: ${armed.doneRubric}", color = MUTED, fontSize = 12.sp)
                Text("Evidence ${evidenceUris.size}/3", color = CYAN)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button({ pick.launch("image/*") }, enabled = evidenceUris.size < 3) { Text("Add screenshot") }
                    Button({
                        if (busy) return@Button
                        busy = true
                        scope.launch {
                            val r = withContext(Dispatchers.IO) {
                                try {
                                    VisionVerify.analyze(ctx, evidenceUris.toList(), armed.title, armed.doneRubric)
                                } catch (e: Exception) {
                                    VisionVerify.Result(false, 0.0, e.message ?: "err")
                                }
                            }
                            busy = false
                            msg = "${r.reason} (conf ${"%.0f".format(r.confidence * 100)}%)"
                            if (r.done && r.confidence >= 0.45) {
                                evidenceUris.forEach { Repo.addEvidence(ctx, armed.id, it.toString()) }
                                Repo.completeTodo(ctx, armed.id)
                                TodoAlarmReceiver.cancel(ctx, armed.id)
                                Repo.logFocus(ctx, "ai_unlock", armed.title)
                                evidenceUris.clear()
                                onChange()
                                Toast.makeText(ctx, "Unlocked", Toast.LENGTH_LONG).show()
                            }
                        }
                    }, enabled = !busy) { Text(if (busy) "Checking…" else "AI verify") }
                }
                TextButton({
                    val r = VisionVerify.selfAttest(ctx, armed.id)
                    if (!Repo.hardMode(ctx)) {
                        Repo.completeTodo(ctx, armed.id)
                        onChange()
                        msg = r.reason
                    } else msg = "Hard mode: self-attest disabled — need AI or second PIN"
                }) { Text("Self-attest (soft mode)", color = MUTED) }
                if (Repo.secondPin(ctx).isNotBlank()) {
                    var sp by remember { mutableStateOf("") }
                    OutlinedTextField(sp, { sp = it }, label = { Text("Second PIN emergency unlock") })
                    TextButton({
                        if (AppLock.checkSecondPin(ctx, sp)) {
                            Repo.saveTodo(ctx, armed.copy(focusArmed = false))
                            Repo.logFocus(ctx, "second_pin", armed.title)
                            onChange()
                        } else Toast.makeText(ctx, "Wrong", Toast.LENGTH_SHORT).show()
                    }) { Text("Emergency disarm") }
                }
                if (msg.isNotBlank()) Text(msg, color = TEXT, fontSize = 12.sp)
            }
        } else {
            Depth(Modifier.fillMaxWidth()) { Text("No task armed — lock icon on Tasks tab", color = MUTED) }
        }
        Depth(Modifier.fillMaxWidth()) {
            Text("Focus log", color = TEXT, fontWeight = FontWeight.Bold)
            Repo.focusLog(ctx).take(12).forEach {
                Text("${fmt(it.ts)} · ${it.kind}: ${it.detail}", color = MUTED, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun ProjectsScreen(projects: List<Project>, todos: List<Todo>, onChange: () -> Unit) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row {
            OutlinedTextField(name, { name = it }, modifier = Modifier.weight(1f), placeholder = { Text("Project name") })
            IconButton({
                if (name.isNotBlank()) {
                    Repo.saveProject(ctx, Project(Repo.newId(), name.trim()))
                    name = ""; onChange()
                }
            }) { Icon(Icons.Default.Add, null, tint = PINK) }
        }
        Text("Kanban", color = TEXT, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 8.dp))
        Row(Modifier.fillMaxSize().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Todo", "Doing", "Done").forEach { col ->
                Column(
                    Modifier.width(200.dp).fillMaxHeight().clip(RoundedCornerShape(16.dp)).background(CARD).padding(8.dp)
                ) {
                    Text(col, color = PINK, fontWeight = FontWeight.Bold)
                    projects.filter { it.status == col }.forEach { p ->
                        Depth(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable {
                            val next = when (p.status) {
                                "Todo" -> "Doing"; "Doing" -> "Done"; else -> "Todo"
                            }
                            Repo.saveProject(ctx, p.copy(status = next)); onChange()
                        }) {
                            Text(p.name, color = TEXT)
                            val count = todos.count { it.projectId == p.id && !it.done }
                            Text("$count open tasks", color = MUTED, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatsScreen() {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Depth(Modifier.fillMaxWidth()) {
            Text("Command glass", color = TEXT, fontWeight = FontWeight.Black, fontSize = 18.sp)
            Text("Completed tasks: ${Repo.statDone(ctx)}", color = CYAN)
            Text("Streak: ${Repo.streak(ctx)} days", color = PINK)
            Text("Focused minutes (logged): ${Repo.focusedMinutes(ctx)}", color = MUTED)
            val overdue = Repo.todos(ctx).count { !it.done && it.dueAt in 1 until System.currentTimeMillis() }
            Text("Overdue now: $overdue", color = if (overdue > 0) Color(0xFFFCA5A5) else MUTED)
        }
        Depth(Modifier.fillMaxWidth()) {
            Text("Morning brief", color = TEXT, fontWeight = FontWeight.Bold)
            Repo.todos(ctx).filter { !it.done }.take(3).forEach {
                Text("• ${it.title}", color = TEXT, fontSize = 13.sp)
            }
            Repo.notes(ctx).firstOrNull()?.let {
                Text("Revisit note: ${it.title.ifBlank { "Untitled" }}", color = MUTED, fontSize = 12.sp)
            }
        }
        Text("Wear / desktop companions: planned hooks in README (v5 ecosystem).", color = MUTED, fontSize = 11.sp)
    }
}

@Composable
private fun SettingsScreen() {
    val ctx = LocalContext.current
    var url by remember { mutableStateOf(Repo.apiUrl(ctx)) }
    var key by remember { mutableStateOf(Repo.apiKey(ctx)) }
    var model by remember { mutableStateOf(Repo.model(ctx)) }
    var pin by remember { mutableStateOf("") }
    var second by remember { mutableStateOf("") }
    var bio by remember { mutableStateOf(Repo.biometricOn(ctx)) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Depth(Modifier.fillMaxWidth()) {
            Text("Vision API", color = TEXT, fontWeight = FontWeight.Bold)
            OutlinedTextField(url, { url = it }, label = { Text("Base URL") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(key, { key = it }, label = { Text("API key") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(model, { model = it }, label = { Text("Model") }, modifier = Modifier.fillMaxWidth())
            Button({
                Repo.setApi(ctx, url, key, model)
                Toast.makeText(ctx, "Saved", Toast.LENGTH_SHORT).show()
            }, Modifier.fillMaxWidth()) { Text("Save API") }
        }
        Depth(Modifier.fillMaxWidth()) {
            Text("Security", color = TEXT, fontWeight = FontWeight.Bold)
            OutlinedTextField(pin, { pin = it }, label = { Text("Set app PIN") }, modifier = Modifier.fillMaxWidth())
            Button({
                if (pin.length >= 4) {
                    Repo.setPin(ctx, pin); Toast.makeText(ctx, "PIN set", Toast.LENGTH_SHORT).show()
                }
            }) { Text("Save PIN") }
            OutlinedTextField(second, { second = it }, label = { Text("Second PIN (emergency disarm)") }, modifier = Modifier.fillMaxWidth())
            Button({
                if (second.length >= 4) Repo.setSecondPin(ctx, second)
            }) { Text("Save second PIN") }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Biometric unlock", color = MUTED, modifier = Modifier.weight(1f))
                Switch(bio, {
                    bio = it; Repo.setBiometric(ctx, it)
                })
            }
        }
        Depth(Modifier.fillMaxWidth()) {
            Text("Backup", color = TEXT, fontWeight = FontWeight.Bold)
            Button({
                val f = Repo.exportFile(ctx)
                Toast.makeText(ctx, "Exported ${f.absolutePath}", Toast.LENGTH_LONG).show()
            }, Modifier.fillMaxWidth()) { Text("Export JSON backup") }
            Button({
                val f = java.io.File(ctx.getExternalFilesDir(null), "aether-backup.json")
                if (f.exists()) {
                    Toast.makeText(ctx, Repo.importAll(ctx, f.readText()), Toast.LENGTH_LONG).show()
                } else Toast.makeText(ctx, "Place aether-backup.json in app external files", Toast.LENGTH_LONG).show()
            }, Modifier.fillMaxWidth()) { Text("Import latest backup file") }
        }
        Depth(Modifier.fillMaxWidth()) {
            Text("Privacy", color = TEXT, fontWeight = FontWeight.Bold)
            Text(
                "Notes/tasks stay on device. Screenshots leave the device only when you run AI verify. Focus Lock does not read other apps’ content. Hindi strings included for system label.",
                color = MUTED, fontSize = 12.sp
            )
        }
    }
}

private fun isAccessibilityEnabled(ctx: Context): Boolean {
    val am = ctx.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
    val expected = "${ctx.packageName}/.focus.FocusLockService"
    return try {
        val cr = ctx.contentResolver
        val enabled = Settings.Secure.getString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        enabled.split(':').any { it.equals(expected, true) || it.endsWith(".focus.FocusLockService") }
    } catch (_: Exception) {
        am.isEnabled
    }
}

private fun ensureExactAlarm(ctx: Context) {
    if (Build.VERSION.SDK_INT >= 31) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (!am.canScheduleExactAlarms()) {
            Toast.makeText(ctx, "Allow exact alarms for reliable reminders", Toast.LENGTH_LONG).show()
        }
    }
}

private fun fmt(ms: Long) = SimpleDateFormat("dd MMM, h:mm a", Locale.getDefault()).format(Date(ms))

private fun pickDateTime(ctx: Context, onPicked: (Long) -> Unit) {
    val cal = Calendar.getInstance()
    DatePickerDialog(ctx, { _, y, m, d ->
        cal.set(y, m, d)
        TimePickerDialog(ctx, { _, h, min ->
            cal.set(Calendar.HOUR_OF_DAY, h)
            cal.set(Calendar.MINUTE, min)
            cal.set(Calendar.SECOND, 0)
            onPicked(cal.timeInMillis)
        }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), false).show()
    }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
}
