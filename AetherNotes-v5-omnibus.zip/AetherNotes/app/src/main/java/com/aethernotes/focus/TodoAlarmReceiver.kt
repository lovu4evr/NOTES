package com.aethernotes.focus

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import com.aethernotes.MainActivity
import com.aethernotes.data.Repo
import com.aethernotes.data.Todo

class TodoAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            ACTION_DONE -> {
                val id = intent.getStringExtra(EXTRA_ID) ?: return
                Repo.completeTodo(context, id)
                cancel(context, id)
            }
            ACTION_SNOOZE -> {
                val id = intent.getStringExtra(EXTRA_ID) ?: return
                val title = intent.getStringExtra(EXTRA_TITLE) ?: "Task"
                val t = Repo.todos(context).firstOrNull { it.id == id } ?: return
                val next = t.copy(dueAt = System.currentTimeMillis() + 10 * 60_000L)
                Repo.saveTodo(context, next)
                schedule(context, next)
            }
            else -> {
                val id = intent.getStringExtra(EXTRA_ID) ?: return
                val title = intent.getStringExtra(EXTRA_TITLE) ?: "Task due"
                notify(context, id, title)
            }
        }
    }

    companion object {
        const val EXTRA_ID = "todo_id"
        const val EXTRA_TITLE = "todo_title"
        const val ACTION_DONE = "com.aethernotes.DONE"
        const val ACTION_SNOOZE = "com.aethernotes.SNOOZE"
        private const val CH_DUE = "aether_due"
        private const val CH_FOCUS = "aether_focus"

        fun schedule(c: Context, todo: Todo) {
            if (todo.dueAt <= 0L || todo.done) {
                cancel(c, todo.id); return
            }
            val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = alarmPi(c, todo.id, todo.title)
            try {
                if (Build.VERSION.SDK_INT >= 31 && am.canScheduleExactAlarms()) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, todo.dueAt, pi)
                } else {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, todo.dueAt, pi)
                }
            } catch (_: Exception) {
                am.set(AlarmManager.RTC_WAKEUP, todo.dueAt, pi)
            }
        }

        fun cancel(c: Context, id: String) {
            val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.cancel(alarmPi(c, id, ""))
        }

        fun rescheduleAll(c: Context) {
            Repo.todos(c).filter { !it.done && it.dueAt > System.currentTimeMillis() }.forEach { schedule(c, it) }
        }

        private fun alarmPi(c: Context, id: String, title: String): PendingIntent {
            val i = Intent(c, TodoAlarmReceiver::class.java).putExtra(EXTRA_ID, id).putExtra(EXTRA_TITLE, title)
            return PendingIntent.getBroadcast(c, id.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }

        fun notify(c: Context, id: String, title: String) {
            val nm = c.getSystemService(NotificationManager::class.java)
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(NotificationChannel(CH_DUE, "Task due", NotificationManager.IMPORTANCE_HIGH))
                nm.createNotificationChannel(NotificationChannel(CH_FOCUS, "Focus", NotificationManager.IMPORTANCE_DEFAULT))
            }
            val open = PendingIntent.getActivity(
                c, id.hashCode(),
                Intent(c, MainActivity::class.java).putExtra("todo_id", id).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val done = PendingIntent.getBroadcast(
                c, id.hashCode() + 1,
                Intent(c, TodoAlarmReceiver::class.java).setAction(ACTION_DONE).putExtra(EXTRA_ID, id),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val snooze = PendingIntent.getBroadcast(
                c, id.hashCode() + 2,
                Intent(c, TodoAlarmReceiver::class.java).setAction(ACTION_SNOOZE).putExtra(EXTRA_ID, id).putExtra(EXTRA_TITLE, title),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val n = android.app.Notification.Builder(c, CH_DUE)
                .setContentTitle("Task due")
                .setContentText(title)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentIntent(open)
                .setAutoCancel(true)
                .addAction(android.app.Notification.Action.Builder(null, "Done", done).build())
                .addAction(android.app.Notification.Action.Builder(null, "Snooze 10m", snooze).build())
                .build()
            nm.notify(id.hashCode(), n)
            Repo.logFocus(c, "notify", title)
        }
    }
}
