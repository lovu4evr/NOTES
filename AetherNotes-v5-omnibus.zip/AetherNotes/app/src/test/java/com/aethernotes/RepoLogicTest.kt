package com.aethernotes

import org.junit.Assert.assertEquals
import org.junit.Test

class RepoLogicTest {
    @Test
    fun priority_ordering_idea() {
        val priorities = listOf(2, 1, 3).sorted()
        assertEquals(listOf(1, 2, 3), priorities)
    }
}
