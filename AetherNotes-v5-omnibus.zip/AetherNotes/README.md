# Aether Notes **5.0.0-omnibus** (v2 → v5 in one tree)

Local-first notes + timed tasks + Focus Lock + AI screenshot verify + projects + stats.

## Implemented across v2–v5

### v2 foundation
- Structured local store (files under `filesDir/aether/`) for notes/todos/projects/profiles/evidence/log
- Export / import JSON backup
- Notification actions: **Done** / **Snooze 10m**
- Exact-alarm awareness (Android 12+)
- Recurring todos (`daily` / `weekly` on complete)
- Tags, notebooks, pin, archive, search
- Biometric + PIN app lock
- Onboarding (3 steps)
- Accessibility **status** in Focus tab
- Focus **whitelist** packages

### v3 discipline
- Focus profiles (Study / Work, hard/soft)
- Multi-screenshot evidence (up to 3) + rubric
- AI vision verify with confidence
- Offline self-attest (blocked in hard mode)
- Templates for tasks
- Priority P1–P3
- Pomodoro-style session minute logging
- Focus event log
- Streaks + completion counters
- Share-to-Aether text capture

### v4 brain
- Projects + simple **Kanban** (Todo / Doing / Done)
- Tasks linked to projects
- Stats / “Command glass” + morning brief
- Note → extract checklist lines into tasks
- Backup schedule = manual export (nightly can be WorkManager later)

### v5 polish / ecosystem (in-app + honest limits)
- Depth / motion UI (tilt cards, neon atmosphere)
- Hindi strings for system Focus Lock label
- Home **widget** (next due task)
- Second PIN emergency disarm (self-contract)
- README hooks for Wear/desktop (not separate binaries in this zip)

## Not a separate binary (by design / platform)
- Full Wear OS app, desktop companion
- Device-owner MDM lock
- On-device embedding search index (structure ready; engine not bundled)
- End-to-end cloud sync (local export only)

## Build
```bash
gradle assembleDebug
```
Package: `com.aethernotes`

## Focus Lock safety
Opt-in Accessibility only. Does not read screen content. User can disarm, complete via AI, self-attest (soft), or second PIN.
