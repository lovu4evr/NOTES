package com.aethernotes.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews
import com.aethernotes.data.Repo
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class DueWidgetReceiver : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        try {
            val next = Repo.todos(context).firstOrNull { !it.done }
            val title = next?.title ?: "No open tasks"
            val sub = when {
                next == null -> "Aether Notes"
                next.dueAt > 0 -> SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()).format(Date(next.dueAt))
                else -> "No due time"
            }
            appWidgetIds.forEach { id ->
                val views = RemoteViews(context.packageName, android.R.layout.simple_list_item_2)
                views.setTextViewText(android.R.id.text1, title)
                views.setTextViewText(android.R.id.text2, sub)
                appWidgetManager.updateAppWidget(id, views)
            }
        } catch (_: Exception) {
            // never crash host process
        }
    }
}
